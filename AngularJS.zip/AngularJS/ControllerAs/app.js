﻿var app = angular.module('myApp', []);
app.controller('myCtrl', function () {
    var vm = this;
    vm.abc = "Akarsh";
})