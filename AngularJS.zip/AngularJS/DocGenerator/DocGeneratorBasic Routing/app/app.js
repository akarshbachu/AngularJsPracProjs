﻿angular.module("docGenerator", ['ui.router'])
.config(function ($stateProvider, $locationProvider) {
    //$locationProvider.hashPrefix("!");
    $stateProvider
        .state('functions', {
            url:'/functions',
            templateUrl: "../templates/functions.html",
            controllerAs:"fCtrl",
            controller: "funcController"
            
        })
        .state('variables', {
            url:'/variables',
            templateUrl: "../templates/variables.html",
            controllerAs: "vCtrl",
            controller: "varController"
        })
        .state('variablesParam', {
            url: '/variables/:i',
            templateUrl: "../templates/product.html",
            controllerAs: "vCtrl",
            controller: "varController"
        })
       // .otherwise({redirectTo:"/functions"});
})

.run(function ($rootScope, $log,$state) {
   //three events will be fired they are
   //$stateChangeSuccess, $stateChangeError, $stateChangeStart 
   $rootScope.$on("$stateChangeStart",function(){
       $log.info("*********changing**********");
   })
   $rootScope.$on("$stateChangeSuccess", function (e, toState, toParams, fromState, fromParams) {
       $log.info('Routing to next Route...'+" from state: "+fromState.name+" to state: "+toState.name);
       if(toState.name==="variables"){
           $log.info("Condition staisfied");
       }
   })
})