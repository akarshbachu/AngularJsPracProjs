﻿angular.module('docGenerator').controller('funcController', function ($scope) {
    $scope.a=10;
})