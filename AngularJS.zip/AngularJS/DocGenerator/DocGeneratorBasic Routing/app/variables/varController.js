﻿angular.module('docGenerator')
    .controller('varController', function ($scope,$stateParams,$state) {
        $scope.i = $stateParams.i;
        $scope.chngState = function (a) {
            $state.go('variablesParam', { i: a });
        }
    })