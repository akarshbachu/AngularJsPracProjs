﻿var app = angular.module('myApp');
app.component('varTemplate',
    {
        templateUrl:'../../templates/variable.html',
        binding: {
            vars: '<',
            i:'<'
        },
        controllerAs: 'specificVar',
        controller: function ($stateParams, $http, $getObjService) {
            //console.log("In controller");
            var specificVar = this;
            //specificVar.$onInit = function () {
            //    console.log("+++" + specificVar.i);
            //}

            specificVar.i = $stateParams.i;
            specificVar.vars = $getObjService.objs;
        }
        
    }
)