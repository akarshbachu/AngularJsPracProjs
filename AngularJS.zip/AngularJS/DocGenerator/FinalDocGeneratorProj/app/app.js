﻿var app = angular.module('myApp', ['ui.router']);

app.config(['$stateProvider', function ($stateProvider) {
    $stateProvider
        .state('menu', {
            url: '/module',
            templateUrl: '../templates/VarsFuncsTemplate.html',
            controller: 'varsFuncsController as vfCtrl'
        })


        .state('variablesTemp', {
            url: '/module/variables',
            templateUrl:'../templates/variablesList.html',
        })

         .state('variable', {
             url: '/module/variables/:i/:j',
             template: ['<var-template vars="specificVar.vars" i="specificVar.i"></var-template>'].join(''),
            
         })

         .state('functionsTemp', {
             url: '/module/functions',
             templateUrl: '../templates/functionsList.html',
          })
        .state('function', {
            url: '/module/functions/:i/:j',
            template: ['<func-template funcs="specificFunc.funcs" i="specificFunc.i"></func-template>'].join(''),
        })

         .state('form', {
             url: '/form',
             templateUrl: '../templates/moduleForm.html',
             controller: 'formController as frmCtrl'
         })
         .state('varsForm', {
             url: '/form/varsForm',
             templateUrl: '../templates/varsForm.html',
             controller: 'varsFormController as vfc'
         })
         .state('funcsForm', {
             url: '/form/funcsForm',
             templateUrl: '../templates/funcsForm.html',
             controller: 'funcsFormController as funcFormCtrl'
         })

        .state('root', {
            url: '/',
            template: 'Click Any Link'
        })
    
}
])
.config(['$qProvider', function ($qProvider) {
    $qProvider.errorOnUnhandledRejections(false);
}]);



