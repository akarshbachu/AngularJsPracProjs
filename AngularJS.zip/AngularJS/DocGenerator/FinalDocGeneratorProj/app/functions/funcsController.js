﻿var app = angular.module('myApp');
app.controller('funcsController', ['$state','$getObjService', function ($state,$getObjService) {

    var fCtrl = this;
    fCtrl.i = 0;
    fCtrl.list = $getObjService.objs2;
    fCtrl.redirectTo = function (pos, vName) {
        vName = fCtrl.list[pos].functionName;
        $state.go('function', { i: pos, j: vName })
    }

    
}])
