﻿var app = angular.module('myApp');
app.component('funcTemplate',
    {
        templateUrl: '../../templates/function.html',
        binding: {
            funcs: '<',
            i: '<'
        },
        controllerAs: 'specificFunc',
        controller: function ($stateParams, $http, $getObjService) {
            var specificFunc = this;
            specificFunc.i = $stateParams.i;
            specificFunc.funcs = $getObjService.objs2;
        },
    }
)