﻿var app = angular.module('myApp');
app.controller('varsFuncsController', function ($state) {
    var vfCtrl = this;
    vfCtrl.redirectToVars = function () {
        $state.go('variablesTemp');
        
    }
    vfCtrl.redirectToFuncs = function () {
        $state.go('functionsTemp');
    }
})