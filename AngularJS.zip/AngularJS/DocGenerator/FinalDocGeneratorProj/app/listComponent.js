﻿var app = angular.module('myApp');
app.component('listComponent', 
    
        {
            templateUrl: '../templates/listDisplay.html',
            binding: {
                list: '<',
                redirectTo: '&'
            },
            controller: 'commonController',
            controllerAs:'cCtrl'
        
        
    }
)