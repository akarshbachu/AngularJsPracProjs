﻿var app = angular.module('myApp');
app.controller('varsFormController', function ($getObjService,$filter,$state) {
    var vfc = this;
    //vfc.lst = $getObjService.objs;
    vfc.ldData = function () {
        vfc.lst2 = $getObjService.vlist;

        //filtering duplicates
        vfc.liOfModules = vfc.lst2.filter(function (value, index) { return vfc.lst2.indexOf(value) == index });
        console.log(vfc.liOfModules);
    }
})