﻿var app = angular.module('myApp');
app.service('$getObjService', function ($http) {
    var objs = [];
    var objs2 = [];

    var flist = [];
    var vlist = [];
    var treeCompatibleJson = [];
    $http.get('variables.json').then(function (response) {
        response.data.forEach(function (obj) {
            objs.push(obj);
        });

        angular.forEach(objs, function (value, key) {
            // console.log(key + ' : ' + value.valueChangeIn);
            angular.forEach(value.valueChangeIn, function (val, k) {
                //console.log(k + ' : ' + val);
                vlist.push(val);
            })
        });

    });
    
    $http.get('functions.json').then(function (response) {
        response.data.forEach(function (obj) {
            objs2.push(obj);

        });

        angular.forEach(objs2, function (value, key) {
            // console.log(key + ' : ' + value.valueChangeIn);
            angular.forEach(value.getsCalledIn, function (val, k) {
                //console.log(k + ' : ' + val);
                flist.push(val);
            })
        });
    });
   
    
    return {
        objs: objs,
        objs2: objs2,
        vlist: vlist,
        flist:flist,
        treeCompatibleJson: function (name) {
            if (name == "variableName") {
                if (treeCompatibleJson.length != 0) {
                     treeCompatibleJson = [];
                }
                for (var i = 0; i < objs.length; i++) {
                        treeCompatibleJson.push({
                            "name": objs[i].variableName,
                            "children": []
                        });

                        for (var j = 0; j < objs[i].valueChangeIn.length; j++) {
                            treeCompatibleJson[i].children.push({
                                "name": objs[i].valueChangeIn[j]
                            });
                        }
                }
                return treeCompatibleJson;
            }
            else {
                if (treeCompatibleJson.length != 0) {
                    treeCompatibleJson = [];
                }
                for (var i = 0; i < objs2.length; i++) {
                  
                    treeCompatibleJson.push({
                        "name": objs2[i].functionName,
                        "children": []
                    });

                    for (var j = 0; j < objs2[i].getsCalledIn.length; j++) {
                        treeCompatibleJson[i].children.push({
                            "name": objs2[i].getsCalledIn[j]
                        });
                    }
                }
                return treeCompatibleJson;
            }
            
        }

    }
})