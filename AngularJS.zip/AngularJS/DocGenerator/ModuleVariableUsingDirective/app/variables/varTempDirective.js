﻿var app = angular.module('myApp');
app.directive('varTemplate', function () {
    return {
        restrict: 'EA',
        scope: {
            vars: '=',
            i:'='
        },
        templateUrl:'../../templates/variable.html'
    }
})