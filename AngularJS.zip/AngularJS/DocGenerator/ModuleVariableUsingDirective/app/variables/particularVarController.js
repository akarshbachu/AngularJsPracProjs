﻿var app = angular.module('myApp');
app.controller('particularVarController', ['$stateParams','$http','$getObjService', function ($stateParams,$http,$getObjService) {
    var specificVar = this;
    specificVar.i = $stateParams.i;
    specificVar.vars = $getObjService.objs;
    
}])