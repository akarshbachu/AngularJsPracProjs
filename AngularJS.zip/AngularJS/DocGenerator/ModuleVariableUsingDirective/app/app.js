﻿var app = angular.module('myApp', ['ui.router']);

app.config(['$stateProvider', function ($stateProvider) {
    $stateProvider
        .state('vars', {
            url: '/module',
            templateUrl: '../templates/VarsFuncsTemplate.html',
            controller: 'varsFuncsController as vfCtrl'
            
        })

        .state('variablesTemp', {
            url: '/module/variables',
            //template: '<list-directive list="list" func="redirectTo" ></list-directive>',
            templateUrl:'../templates/variablesList.html',
            controller: 'varController as vCtrl'
        })

         .state('variable', {
             url: '/module/variables/:i/:j',
             template: ['<div var-template vars="specificVar.vars" i="specificVar.i"></div>'].join(''),
             controller: 'particularVarController as specificVar',
            
         })

          .state('functionsTemp', {
              url: '/module/functions',
              template: '<list-directive list="fCtrl.list" func="fCtrl.redirectTo"></list-directive>',
              controller: 'funcsController as fCtrl'
             
          })
        .state('function', {
            url: '/module/functions/:i/:j',
            template: ['<div func-template funcs="specificFunc.funcs" i="specificFunc.i"></div>'].join(''),
            controller: 'particularFuncController as specificFunc',

        })

        .state('root', {
            url: '/',
            template: 'Click Any Link'
        })
    
}
])
.config(['$qProvider', function ($qProvider) {
    $qProvider.errorOnUnhandledRejections(false);
}]);



