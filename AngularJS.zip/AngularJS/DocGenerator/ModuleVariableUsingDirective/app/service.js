﻿var app = angular.module('myApp');
app.service('$getObjService', function ($http) {
    var objs = [];
    var objs2 = [];
    $http.get('variables.json').then(function (response) {
        response.data.forEach(function (obj) {
            objs.push(obj);
        })
    });
    $http.get('functions.json').then(function (response) {
        response.data.forEach(function (obj) {
            objs2.push(obj);
        })
    });
    return {
        objs: objs,
        objs2: objs2
    }
})