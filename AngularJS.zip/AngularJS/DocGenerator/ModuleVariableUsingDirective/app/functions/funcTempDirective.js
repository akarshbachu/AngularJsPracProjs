﻿var app = angular.module('myApp');
app.directive('funcTemplate', function () {
    return {
        restrict: 'EA',
        scope:{
            funcs: '=',
            i:'='
        },
        templateUrl: '../../templates/function.html'
    }
})