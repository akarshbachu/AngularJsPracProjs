﻿var app = angular.module('myApp');
app.controller('particularFuncController', ['$stateParams', '$http', '$getObjService', function ($stateParams, $http, $getObjService) {
    var specificFunc = this;
    specificFunc.i = $stateParams.i;
    specificFunc.funcs = $getObjService.objs2;

    
}])