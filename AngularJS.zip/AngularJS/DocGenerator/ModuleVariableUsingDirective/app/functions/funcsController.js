﻿var app = angular.module('myApp');
app.controller('funcsController', ['$stateParams', '$state', '$http', '$getObjService', function ($stateParams, $state, $http, $getObjService) {

    var fCtrl = this;
    fCtrl.i = 0;
    fCtrl.list = $getObjService.objs2;
    fCtrl.redirectTo = function (pos, vName) {
        vName = fCtrl.list[pos].funcName;
        $state.go('function', { i: pos, j: vName })
    }

    
}])
