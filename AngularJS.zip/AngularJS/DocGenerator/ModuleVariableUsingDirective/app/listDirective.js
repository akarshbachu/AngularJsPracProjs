﻿var app = angular.module('myApp');
app.directive('listDirective', function () {
    return {
        restrict: 'EA',
        scope: {
            list: '=',
            func: '&',
        },
        
        templateUrl: '../templates/listDisplay.html'
        
    }
})